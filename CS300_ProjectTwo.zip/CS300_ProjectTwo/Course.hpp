#ifndef COURSE_HPP
#define COURSE_HPP

#include <string>
#include <vector>

using namespace std;

/**
 * Struct to represent a course with a course number, title, and prerequisites.
 */
struct Course {
    string courseNumber;  // Course identifier (e.g., CS101)
    string courseTitle;   // Title of the course
    vector<string> prerequisites;  // List of prerequisite course numbers

    // Default constructor
    Course() {}

    // Parameterized constructor
    Course(string number, string title, vector<string> prereqs)
        : courseNumber(number), courseTitle(title), prerequisites(prereqs) {}
};

#endif
