#include <iostream>
#include "BinarySearchTree.hpp"
#include "Course.hpp"
#include "CourseDataLoader.hpp"

using namespace std;

/**
 * Function to display the menu options to the user.
 */
void displayMenu() {
    cout << "Welcome to the course planner." << endl;
    cout << "1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;
}

/**
 * Main function to run the course planner program.
 */
int main() {
    BinarySearchTree<Course> bst;
    int choice = 0;
    bool dataLoaded = false;  // Flag to check if data is loaded

    while (choice != 9) {
        displayMenu();
        cout << "What would you like to do? ";
        cin >> choice;

        // Validate user input to ensure a valid menu option is chosen
        if (cin.fail() || (choice != 1 && choice != 2 && choice != 3 && choice != 9)) {
            cin.clear(); // Clear the input buffer
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore remaining input
            cout << "Invalid choice. Please enter a number between 1 and 9." << endl;
            continue;
        }

        switch (choice) {
            case 1: {
                string fileName;
                cout << "Enter the course data file name: ";
                cin >> fileName;
                bst = CourseDataLoader::loadCourses(fileName);
                if (!bst.isEmpty()) {
                    dataLoaded = true;
                    cout << "Courses loaded successfully." << endl;
                } else {
                    cout << "No courses loaded. Please check the file." << endl;
                }
                break;
            }
            case 2: {
                if (dataLoaded) {
                    bst.inOrderTraversal();  // Print all courses in alphanumeric order
                } else {
                    cout << "Error: No data loaded. Please load data before printing the course list." << endl;
                }
                break;
            }
            case 3: {
                if (dataLoaded) {
                    string courseNumber;
                    cout << "What course do you want to know about? ";
                    cin >> courseNumber;
                    Course course = bst.search(courseNumber);  // Search for the course
                    if (!course.courseNumber.empty()) {
                        cout << course.courseNumber << ", " << course.courseTitle << endl;
                        cout << "Prerequisites: ";
                        if (course.prerequisites.empty()) {
                            cout << "None" << endl;
                        } else {
                            for (string prereq : course.prerequisites) {
                                cout << prereq << " ";
                            }
                            cout << endl;
                        }
                    } else {
                        cout << "Course not found." << endl;
                    }
                } else {
                    cout << "Error: No data loaded. Please load data before searching for a course." << endl;
                }
                break;
            }
            case 9:
                cout << "Thank you for using the course planner!" << endl;
                break;
        }
    }

    return 0;
}
