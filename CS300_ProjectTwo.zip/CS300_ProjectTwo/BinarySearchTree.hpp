#ifndef BINARY_SEARCH_TREE_HPP
#define BINARY_SEARCH_TREE_HPP

#include <iostream>
#include "Course.hpp"

template<typename T>
struct Node {
    T data;        // Data of the node, of type T
    Node* left;    // Pointer to the left child node
    Node* right;   // Pointer to the right child node

    // Constructor to initialize node with data
    Node(T value) : data(value), left(nullptr), right(nullptr) {}
};

template<typename T>
class BinarySearchTree {
private:
    Node<T>* root;  // Root node of the BST

    void inOrderTraversal(Node<T>* node) const;
    Node<T>* insert(Node<T>* node, T data);
    Node<T>* search(Node<T>* node, string courseNumber) const;

public:
    BinarySearchTree();
    void insert(T data);
    T search(string courseNumber) const;
    void inOrderTraversal() const;
    bool isEmpty() const;  // Check if the tree is empty
};

#include "BinarySearchTree.cpp"  // Include the implementation file

#endif
