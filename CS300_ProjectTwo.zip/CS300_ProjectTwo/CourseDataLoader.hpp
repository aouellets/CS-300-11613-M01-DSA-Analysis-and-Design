#ifndef COURSE_DATA_LOADER_HPP
#define COURSE_DATA_LOADER_HPP

#include <iostream>
#include <fstream>
#include <sstream>
#include "BinarySearchTree.hpp"
#include "Course.hpp"

class CourseDataLoader {
public:
    /**
     * Static method to load courses from a CSV file and insert them into a BST.
     * Returns the populated BST.
     */
    static BinarySearchTree<Course> loadCourses(string fileName) {
        BinarySearchTree<Course> bst;
        ifstream file(fileName);

        // Check if file could not be opened
        if (!file.is_open()) {
            cerr << "Error: Could not open file " << fileName << endl;
            return bst;
        }

        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string courseNumber, courseTitle, prereq;
            vector<string> prerequisites;

            // Read course number and title
            getline(ss, courseNumber, ',');
            getline(ss, courseTitle, ',');

            // Read all prerequisites
            while (getline(ss, prereq, ',')) {
                prerequisites.push_back(prereq);
            }

            // Create a course object and insert it into the BST
            Course course(courseNumber, courseTitle, prerequisites);
            bst.insert(course);
        }

        file.close();
        return bst;
    }
};

#endif
