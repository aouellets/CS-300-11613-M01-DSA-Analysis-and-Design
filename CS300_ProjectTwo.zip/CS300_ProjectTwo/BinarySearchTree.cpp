#include "BinarySearchTree.hpp"

template<typename T>
BinarySearchTree<T>::BinarySearchTree() : root(nullptr) {}

/**
 * Insert a node with the given data into the BST.
 * Recursively find the correct position for the new node.
 */
template<typename T>
Node<T>* BinarySearchTree<T>::insert(Node<T>* node, T data) {
    if (node == nullptr) {
        return new Node<T>(data);
    }
    if (data.courseNumber < node->data.courseNumber) {
        node->left = insert(node->left, data);
    } else {
        node->right = insert(node->right, data);
    }
    return node;
}

/**
 * Public method to insert data into the BST.
 */
template<typename T>
void BinarySearchTree<T>::insert(T data) {
    root = insert(root, data);
}

/**
 * Search for a node with the given course number in the BST.
 * Return the node if found, otherwise return nullptr.
 */
template<typename T>
Node<T>* BinarySearchTree<T>::search(Node<T>* node, string courseNumber) const {
    if (node == nullptr || node->data.courseNumber == courseNumber) {
        return node;
    }
    if (courseNumber < node->data.courseNumber) {
        return search(node->left, courseNumber);
    } else {
        return search(node->right, courseNumber);
    }
}

/**
 * Public method to search for a course by course number.
 * Return the course if found, otherwise return an empty course object.
 */
template<typename T>
T BinarySearchTree<T>::search(string courseNumber) const {
    Node<T>* node = search(root, courseNumber);
    if (node == nullptr) {
        return T();  // Return an empty object if not found
    }
    return node->data;
}

/**
 * Perform in-order traversal of the BST.
 * This will print all courses in alphanumeric order.
 */
template<typename T>
void BinarySearchTree<T>::inOrderTraversal(Node<T>* node) const {
    if (node != nullptr) {
        inOrderTraversal(node->left);
        cout << node->data.courseNumber << ", " << node->data.courseTitle << endl;
        inOrderTraversal(node->right);
    }
}

/**
 * Public method to initiate in-order traversal from the root.
 */
template<typename T>
void BinarySearchTree<T>::inOrderTraversal() const {
    inOrderTraversal(root);
}

/**
 * Check if the BST is empty.
 * Return true if the root is null, otherwise false.
 */
template<typename T>
bool BinarySearchTree<T>::isEmpty() const {
    return root == nullptr;
}
