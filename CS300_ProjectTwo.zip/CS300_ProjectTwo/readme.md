# ABCU Advising Assistance Program

## Project Overview

This project is a course advising assistance program for the Computer Science department at ABCU (ABC University). The program allows academic advisors to load course data from a CSV file, search for course information, and display an alphanumeric list of all the courses offered. The program is written in C++ and uses a Binary Search Tree (BST) data structure to efficiently manage and search course data.

## Features

- **Load Course Data:** Reads a CSV file containing course information, including course numbers, titles, and prerequisites, and stores the data in a Binary Search Tree (BST).
- **Display Course List:** Prints a sorted (alphanumeric) list of all the courses.
- **Search Course Information:** Allows the user to search for a course by course number and displays its title and prerequisites.
- **User-Friendly Interface:** The program includes a menu that guides users through the available options.
- **Error Handling:** The program handles common errors, such as file not found, invalid user input, and operations attempted before loading data.

## Project Structure

The project is organized into the following files:

- **ProjectTwo.cpp**: The main driver of the program, responsible for displaying the menu and handling user input.
- **Course.hpp**: Defines the `Course` struct, representing a course with its number, title, and prerequisites.
- **BinarySearchTree.hpp**: Contains the implementation of the Binary Search Tree data structure.
- **CourseDataLoader.hpp**: Handles loading course data from a CSV file into the BST.
- **CS 300 ABCU_Advising_Program_Input.csv**: Sample input CSV file containing course data.

## How to Run

1. **Compilation**: 
   - Ensure you have a C++ compiler installed (e.g., g++, clang++).
   - Compile the program using the following command:

   ```bash
   g++ ProjectTwo.cpp -o ABCU_Advising
